if(typeof KindEditor !== 'undefined') KindEditor.pluginOk = true;
